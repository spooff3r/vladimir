﻿using System.Drawing;
using System.Windows.Forms;

namespace ComputerPriceCalculator
{
    partial class Form1 : Form  
    {
        private ComboBox comboBoxCPU;
        private ComboBox comboBoxMotherboard;
        private ComboBox comboBoxRAM;
        private ComboBox comboBoxStorage;
        private ComboBox comboBoxGPU;
        private ComboBox comboBoxPSU;
        private ComboBox comboBoxCase;
        private ComboBox comboBoxCooling;
        private Label lblTotal;

        private GroupBox groupBoxCPU;
        private GroupBox groupBoxMotherboard;
        private GroupBox groupBoxRAM;
        private GroupBox groupBoxStorage;
        private GroupBox groupBoxGPU;
        private GroupBox groupBoxPSU;
        private GroupBox groupBoxCase;
        private GroupBox groupBoxCooling;

        private void InitializeComponent()
        {
            // Инициализация элементов управления
            this.groupBoxCPU = new GroupBox();
            this.comboBoxCPU = new ComboBox();
            this.groupBoxMotherboard = new GroupBox();
            this.comboBoxMotherboard = new ComboBox();
            this.groupBoxRAM = new GroupBox();
            this.comboBoxRAM = new ComboBox();
            this.groupBoxStorage = new GroupBox();
            this.comboBoxStorage = new ComboBox();
            this.groupBoxGPU = new GroupBox();
            this.comboBoxGPU = new ComboBox();
            this.groupBoxPSU = new GroupBox();
            this.comboBoxPSU = new ComboBox();
            this.groupBoxCase = new GroupBox();
            this.comboBoxCase = new ComboBox();
            this.groupBoxCooling = new GroupBox();
            this.comboBoxCooling = new ComboBox();
            this.lblTotal = new Label();

            // 
            // MainForm
            // 
            this.ClientSize = new Size(680, 720);
            this.Text = "Калькулятор стоимости системного блока";
            this.BackColor = Color.WhiteSmoke;
            this.Padding = new Padding(20);
            this.Font = new Font("Segoe UI", 9F);

            // Настройка GroupBox и ComboBox
            int yPosition = 20;
            ConfigureGroupBox(groupBoxCPU, "Процессор", comboBoxCPU, yPosition);
            yPosition += 80;

            ConfigureGroupBox(groupBoxMotherboard, "Материнская плата", comboBoxMotherboard, yPosition);
            yPosition += 80;

            ConfigureGroupBox(groupBoxRAM, "Оперативная память", comboBoxRAM, yPosition);
            yPosition += 80;

            ConfigureGroupBox(groupBoxStorage, "Накопитель", comboBoxStorage, yPosition);
            yPosition += 80;

            ConfigureGroupBox(groupBoxGPU, "Видеокарта", comboBoxGPU, yPosition);
            yPosition += 80;

            ConfigureGroupBox(groupBoxPSU, "Блок питания", comboBoxPSU, yPosition);
            yPosition += 80;

            ConfigureGroupBox(groupBoxCase, "Корпус", comboBoxCase, yPosition);
            yPosition += 80;

            ConfigureGroupBox(groupBoxCooling, "Охлаждение", comboBoxCooling, yPosition);

            // Настройка Label
            this.lblTotal.Text = "Итоговая стоимость: 0 ₽";
            this.lblTotal.Location = new Point(20, 650);
            this.lblTotal.Size = new Size(640, 40);
            this.lblTotal.Font = new Font("Segoe UI Semibold", 14F);
            this.lblTotal.ForeColor = Color.DarkGreen;
            this.lblTotal.TextAlign = ContentAlignment.MiddleCenter;
            this.lblTotal.BorderStyle = BorderStyle.Fixed3D;

            // Добавление элементов на форму
            this.Controls.AddRange(new Control[] {
                groupBoxCPU, groupBoxMotherboard, groupBoxRAM,
                groupBoxStorage, groupBoxGPU, groupBoxPSU,
                groupBoxCase, groupBoxCooling, lblTotal
            });
        }

        private void ConfigureGroupBox(GroupBox groupBox, string title, ComboBox comboBox, int yPosition)
        {
            groupBox.Text = title;
            groupBox.Location = new Point(20, yPosition);
            groupBox.Size = new Size(640, 70);
            groupBox.Font = new Font("Segoe UI Semibold", 10F);
            groupBox.ForeColor = Color.Navy;
            groupBox.Controls.Add(comboBox);

            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox.Location = new Point(10, 25);
            comboBox.Size = new Size(620, 25);
            comboBox.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
        }
    }
}