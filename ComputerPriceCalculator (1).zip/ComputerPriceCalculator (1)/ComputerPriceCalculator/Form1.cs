﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ComputerPriceCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeComponents();
            SetupUI();
        }

        private void InitializeComponents()
        {
            // Инициализация выпадающих списков
            InitializeComboBox(comboBoxCPU, new[]
            {
                new Component("Intel Core i3-13100", 12000),
                new Component("AMD Ryzen 5 5600", 15000),
                new Component("Intel Core i7-13700", 25000)
            });

            InitializeComboBox(comboBoxMotherboard, new[]
            {
                new Component("ASRock B760M", 8000),
                new Component("MSI B550-A PRO", 9500),
                new Component("ASUS ROG Strix Z790", 14000)
            });

            InitializeComboBox(comboBoxRAM, new[]
            {
                new Component("DDR4 16GB 3200MHz", 4000),
                new Component("DDR4 32GB 3600MHz", 8500),
                new Component("DDR5 32GB 6000MHz", 12000)
            });

            InitializeComboBox(comboBoxStorage, new[]
            {
                new Component("1TB NVMe SSD", 5000),
                new Component("2TB NVMe SSD", 8000),
                new Component("4TB NVMe SSD", 12000)
            });

            InitializeComboBox(comboBoxGPU, new[]
            {
                new Component("RTX 3050 8GB", 18000),
                new Component("RTX 4060 Ti 16GB", 30000),
                new Component("RTX 4080 16GB", 60000)
            });

            InitializeComboBox(comboBoxPSU, new[]
            {
                new Component("500W 80+ Bronze", 3500),
                new Component("650W 80+ Gold", 5500),
                new Component("850W 80+ Platinum", 9000)
            });

            InitializeComboBox(comboBoxCase, new[]
            {
                new Component("Mid Tower ATX", 2500),
                new Component("Full Tower RGB", 4500),
                new Component("Mini-ITX Cube", 6000)
            });

            InitializeComboBox(comboBoxCooling, new[]
            {
                new Component("Stock Cooler", 0),
                new Component("Cooler Master Hyper 212", 2500),
                new Component("NZXT Kraken X63", 8000)
            });
        }

        private void InitializeComboBox(ComboBox comboBox, Component[] components)
        {
            comboBox.DisplayMember = "Name";
            comboBox.ValueMember = "Price";
            comboBox.Items.AddRange(components);
            comboBox.SelectedIndex = 0;
            comboBox.SelectedIndexChanged += Component_SelectedIndexChanged;
            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void SetupUI()
        {
            // Настройка основного окна
            Text = "Калькулятор стоимости системного блока";
            BackColor = Color.WhiteSmoke;
            Padding = new Padding(20);
            Font = new Font("Segoe UI", 9);
            Size = new Size(600, 500);

            // Настройка групп компонентов
            foreach (Control control in Controls)
            {
                if (control is GroupBox groupBox)
                {
                    groupBox.Font = new Font("Segoe UI Semibold", 10);
                    groupBox.ForeColor = Color.Navy;
                    groupBox.BackColor = Color.White;
                    groupBox.Padding = new Padding(10);
                }
            }

            // Настройка итоговой метки
            lblTotal.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblTotal.ForeColor = Color.DarkGreen;
            lblTotal.TextAlign = ContentAlignment.MiddleCenter;
            lblTotal.BorderStyle = BorderStyle.Fixed3D;
            lblTotal.Height = 40;
        }

        private void Component_SelectedIndexChanged(object sender, EventArgs e)
        {
            CalculateTotal();
        }

        private void CalculateTotal()
        {
            int total = 0;

            total += GetSelectedPrice(comboBoxCPU);
            total += GetSelectedPrice(comboBoxMotherboard);
            total += GetSelectedPrice(comboBoxRAM);
            total += GetSelectedPrice(comboBoxStorage);
            total += GetSelectedPrice(comboBoxGPU);
            total += GetSelectedPrice(comboBoxPSU);
            total += GetSelectedPrice(comboBoxCase);
            total += GetSelectedPrice(comboBoxCooling);

            lblTotal.Text = $"Итоговая стоимость: {total:C0}";
        }

        private int GetSelectedPrice(ComboBox comboBox)
        {
            return (comboBox.SelectedItem as Component)?.Price ?? 0;
        }
    }

    public class Component
    {
        public string Name { get; set; }
        public int Price { get; set; }

        public Component(string name, int price)
        {
            Name = name;
            Price = price;
        }

        public override string ToString()
        {
            return $"{Name} - {Price:C0}";
        }
    }
}